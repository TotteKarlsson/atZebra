========================================================================
       DYNAMIC LINK LIBRARY : SSIdll
========================================================================

CAUTION:  When this DLL IS REBULT YOU MUST REPLACE THE DLL IN THE 
APPFORDLL\RELEASE DIRECTORY OF THIS PROJECT AND
SSICONTROL\RELEASE DIRECTORY OF THIS PROJECT 

When the SSI DLL is released, the files that must be released are as follows:

ssidll\release\ssidll.lib
ssidll\release\ssidll.dll
ssidll\ssicontrol\release\SSIConnect.ocx




AppWizard has created this SSIdll DLL for you.  

This file contains a summary of what you will find in each of the files that
make up your SSIdll application.

SSIdll.dsp
    This file (the project file) contains information at the project level and
    is used to build a single project or subproject. Other users can share the
    project (.dsp) file, but they should export the makefiles locally.

SSIdll.cpp
    This is the main DLL source file.

SSIdll.h
    This file contains your DLL exports.

/////////////////////////////////////////////////////////////////////////////
Other standard files:

StdAfx.h, StdAfx.cpp
    These files are used to build a precompiled header (PCH) file
    named SSIdll.pch and a precompiled types file named StdAfx.obj.


/////////////////////////////////////////////////////////////////////////////
Other notes:

AppWizard uses "TODO:" to indicate parts of the source code you
should add to or customize.




/////////////////////////////////////////////////////////////////////////////
